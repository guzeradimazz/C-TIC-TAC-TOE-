//
//  main.cpp
//  cross
//
//  Created by Дима Гузерчук on 22.12.20.
//

#include <iostream>

using namespace std;


char board[3][3] ={ ' ',' ',' ',
                    ' ',' ',' ',
                    ' ',' ',' '
                   };
int turn = 1;
char mark = 'O';
int input;
void printInputMatrix(){
    cout << endl << "INPUT" << endl;
    cout << " 1 | 2 | 3 " << endl;
    cout << " 4 | 5 | 6 " << endl;
    cout << " 7 | 8 | 9 " << endl;
}
void printBoard(){
    for (int i = 0 ; i < 50; i++) {
        cout << endl;
    }
    cout <<  board[0][0] << "|" <<  board[0][1] << "|"<< board[0][2]  << endl;
    cout <<  board[1][0] << "|" <<  board[1][1] << "|"<< board[1][2]  << endl;
    cout <<  board[2][0] << "|" <<  board[2][1] << "|"<< board[2][2]  << endl;

}
int addMark(){
    for (int i = 0, k = 1; i < 3; i++) {
        for (int j = 0; j < 3; j++,k++) {
            if (k == input) {
                if (board[i][j] == ' ') {
                    board[i][j] = mark;
                    return 1;
                }
                else{
                    cout << "Please, input only correct number" << endl;
                    return 0;
                }
            }
        }
    }
    return 0;
}
int check(){//rows
    if (board[0][0] == mark && board[0][1] == mark && board[0][2] == mark) {
        return 1;
    }
    if (board[1][0] == mark && board[1][1] == mark && board[1][2] == mark) {
        return 1;
    }
    if (board[2][0] == mark && board[2][1] == mark && board[2][2] == mark) {
        return 1;
    }
    //columns
    if (board[0][0] == mark && board[1][0] == mark && board[2][0] == mark) {
        return 1;
    }
    if (board[0][1] == mark && board[1][1] == mark && board[2][1] == mark) {
        return 1;
    }
    if (board[0][2] == mark && board[1][2] == mark && board[2][2] == mark) {
        return 1;
    }
    //diagonals
    if (board[0][0] == mark && board[1][1] == mark && board[2][2] == mark) {
        return 1;
    }
    if (board[0][2] == mark && board[1][1] == mark && board[2][0] == mark) {
        return 1;
    }
    return 0;
}
int main() {
    int won = 0;
    int validInput = 0;
    for (int i = 0; i < 9; i++) {
        printBoard();
        if (turn) {
            cout << "Player 1 Turn (Symbol : O)" << endl;
        }else{
            cout << "Player 2 Turn (Symbol : X)" << endl;
        }
        printInputMatrix();
        cout << "Enter input from table" << endl;
        cin >> input;
        while(input < 0 || input > 9){
            cout << "Please, input only correct number" << endl;
            cin >> input;
        }
        if (turn) {
            mark = 'O';
        }else{
            mark = 'X';
        }
        
        validInput = addMark();
        if (!validInput) {
            i--;
            continue;
        }
        won = check();
        if (won) {
            printBoard();
            if (turn) {
                cout<< "CONGRAULATIONS!!! PLAYER 1 WON!!!" << endl;
            }else{
                cout<< "CONGRAULATIONS!!! PLAYER 2 WON!!!" << endl;
            }
            break;
        }
        if (i == 8) {
            printBoard();
             
        }
        turn = !turn;
        
    }
    return 0;
}
